"""
Loads real, pretrained chest X-ray classifiers from TorchXRayVision
(https://github.com/mlmed/torchxrayvision) and runs inference on uploaded
images.

TorchXRayVision ships DenseNet-121 weights trained on real public chest
X-ray datasets. We expose four of them:

  - "all"      -> densenet121-res224-all
                  A single DenseNet-121 trained on a MERGE of NIH
                  ChestX-ray14, CheXpert, MIMIC-CXR, PadChest, the RSNA
                  Pneumonia Challenge set, SIIM-ACR Pneumothorax, and the
                  NLM Montgomery/Shenzhen TB sets. This is the best default
                  general-purpose model and is what most requests should use.
  - "nih"      -> densenet121-res224-nih       (NIH ChestX-ray14 only)
  - "chexpert" -> densenet121-res224-chex      (Stanford CheXpert only)
  - "mimic"    -> densenet121-res224-mimic_ch  (MIMIC-CXR only)

Passing ensemble=True to /v1/analyze-cxr averages the nih + chexpert + mimic
models (i.e. genuinely combines predictions trained separately on NIH
ChestX-Rays, CheXpert, and MIMIC-CXR, as opposed to the single pre-merged
"all" checkpoint).

Weights are downloaded automatically by torchxrayvision on first use (~30MB
each) and cached under ~/.cache/torch or TORCH_HOME. This module does not
bundle any weights itself.
"""

import io
import logging
from typing import Dict, List

import numpy as np
import torch

try:
    import torchxrayvision as xrv
except ImportError as exc:  # pragma: no cover - surfaced clearly at startup
    raise ImportError(
        "torchxrayvision is not installed. Run `pip install -r requirements.txt`."
    ) from exc

from PIL import Image

logger = logging.getLogger("cxr-backend.model")

MODEL_REGISTRY: Dict[str, Dict] = {
    "all": {
        "weights": "densenet121-res224-all",
        "trained_on": [
            "NIH ChestX-ray14",
            "CheXpert (Stanford)",
            "MIMIC-CXR",
            "PadChest",
            "RSNA Pneumonia Challenge",
            "SIIM-ACR Pneumothorax",
            "NLM Montgomery/Shenzhen (TB)",
        ],
        "description": "Combined multi-dataset DenseNet-121 (recommended default).",
    },
    "nih": {
        "weights": "densenet121-res224-nih",
        "trained_on": ["NIH ChestX-ray14"],
        "description": "Trained only on the NIH ChestX-ray14 dataset.",
    },
    "chexpert": {
        "weights": "densenet121-res224-chex",
        "trained_on": ["CheXpert (Stanford)"],
        "description": "Trained only on the CheXpert dataset.",
    },
    "mimic": {
        "weights": "densenet121-res224-mimic_ch",
        "trained_on": ["MIMIC-CXR (MIT/BIDMC)"],
        "description": "Trained only on the MIMIC-CXR dataset.",
    },
}

_loaded_models: Dict[str, "xrv.models.DenseNet"] = {}


def get_model(key: str):
    """Lazily loads (and caches in-process) a TorchXRayVision DenseNet-121."""
    if key not in MODEL_REGISTRY:
        raise KeyError(f"Unknown model key '{key}'. Options: {list(MODEL_REGISTRY)}")
    if key not in _loaded_models:
        weights = MODEL_REGISTRY[key]["weights"]
        logger.info("Loading TorchXRayVision weights: %s", weights)
        model = xrv.models.DenseNet(weights=weights)
        model.eval()
        _loaded_models[key] = model
    return _loaded_models[key]


def preload_default_models(keys: List[str]) -> None:
    """Warms the given models at process startup so the first request is fast."""
    for key in keys:
        get_model(key)


def _prepare_tensor(image_bytes: bytes) -> torch.Tensor:
    """Grayscale, crop, resize, and normalize an image the way TorchXRayVision expects."""
    pil_img = Image.open(io.BytesIO(image_bytes)).convert("L")
    img = np.array(pil_img).astype(np.float32)

    # TorchXRayVision models expect images scaled to roughly [-1024, 1024].
    img = xrv.datasets.normalize(img, 255)
    img = img[None, :, :]  # add channel dim -> (1, H, W)

    img = xrv.datasets.XRayCenterCrop()(img)
    img = xrv.datasets.XRayResizer(224)(img)

    return torch.from_numpy(img).unsqueeze(0).float()  # (1, 1, 224, 224)


@torch.no_grad()
def run_inference(image_bytes: bytes, model_key: str = "all") -> Dict[str, float]:
    """Runs a single model and returns {pathology_label: probability}."""
    model = get_model(model_key)
    tensor = _prepare_tensor(image_bytes)
    outputs = model(tensor).cpu().numpy()[0]
    return {
        label: float(prob)
        for label, prob in zip(model.pathologies, outputs)
        if label  # torchxrayvision pads unused label slots with ""
    }


@torch.no_grad()
def run_ensemble_inference(image_bytes: bytes, model_keys: List[str]) -> Dict[str, float]:
    """Runs several models on the same image and averages overlapping labels."""
    tensor = _prepare_tensor(image_bytes)
    accum: Dict[str, List[float]] = {}
    for key in model_keys:
        model = get_model(key)
        outputs = model(tensor).cpu().numpy()[0]
        for label, prob in zip(model.pathologies, outputs):
            if not label:
                continue
            accum.setdefault(label, []).append(float(prob))
    return {label: float(np.mean(probs)) for label, probs in accum.items()}
